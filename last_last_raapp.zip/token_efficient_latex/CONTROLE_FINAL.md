# Contrôle final du rapport — 3 octobre 2026

## Modifications livrées

- Logo EMSI de l'école ajouté sans altération du fichier fourni.
- Couverture allégée : deux lignes sous le logo de l'école retirées, bande
  verte amincie, angle réduit et filets plus fins ; corps du rapport en noir et gris.
- Couleurs conservées dans les dix diagrammes et graphiques.
- Six captures présentes et reliées aux légendes du chapitre 4.
- Bibliographie : lien Ollama rétabli et caractère isolé supprimé.
- Graphique des répétitions : alignement distinct des valeurs des deux séries.
- Modèle de données : espacement vertical augmenté et libellé débordant retiré.
- Dictionnaire : noms de champs autorisés à revenir à la ligne.
- Versions Python et Ollama renseignées avec leur source et la date du relevé.

## Vérifications effectuées

- Dernier PDF disponible : `rapport_token_efficient-1.pdf`, 52 pages, antérieur
  aux corrections finales. Revue de toutes les pages en vue d'ensemble et
  inspection détaillée des pages comportant les défauts corrigés.
- 31 étiquettes uniques ; tous les renvois de la source correspondent à une
  étiquette connue, y compris les six légendes générées par la macro de capture.
- Toutes les citations correspondent aux six entrées bibliographiques.
- Environnements LaTeX équilibrés ; deux logos et six captures présents.
- Totaux des six essais v12 recalculés depuis leurs traces ; moyenne de
  52,3569848766 % et écart-type d'échantillon de 7,197789691 points confirmés.
- Essais courts E3 et E5 : 5 144 / 4 306 / 2 959 tokens ; économie totale
  de 2 185 tokens, dont 838 pour la différence de compression seule et
  1 347 pour la différence additionnelle avec routage.
- Cas v13 réfrigéré : 12 016 / 10 180 / 5 232 tokens ; deux autres cas
  distincts arrêtés pour revue, sans décision ni économie d'inférence mesurée.

## À vérifier après recompilation externe

Le compilateur intégré échoue au démarrage avec :
`Unable to find standard directories for platform`.
Il ne s'agit pas d'un diagnostic LaTeX établissant la validité ou l'invalidité
du document. Le PDF révisé n'a donc pas encore pu être rendu ici.

Après import du ZIP complet, choisir `rapport_token_efficient.tex` comme
document principal et compiler avec pdfLaTeX. Vérifier particulièrement :

1. Les deux logos, la couverture verte et l'absence de débordement de la page de garde.
2. Les espacements du diagramme de données et les valeurs du graphique des répétitions.
3. Les retours à la ligne dans le dictionnaire, les renvois et la bibliographie.
4. L'année universitaire : 2025/2026 est conservée selon l'indication initiale ;
   les essais décrits sont datés d'octobre 2026.

La période de stage reste retirée à la demande de l'étudiant. Cette note de
préparation est séparée du mémoire et n'a pas à être envoyée au jury.
