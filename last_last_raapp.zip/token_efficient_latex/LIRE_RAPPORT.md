# Rapport Token Efficient — guide d'édition

Le rapport est rédigé en français, avec un abstract en anglais. Il adapte la
structure du PDF de référence au projet Token Efficient. L'ancien fichier
`rapport_pfa.tex` est conservé séparément ; le nouveau point d'entrée est
`rapport_token_efficient.tex`.

## Ouvrir et modifier

1. Ouvrir `rapport_token_efficient.tex` dans l'éditeur LaTeX intégré de Codex,
   ou importer le ZIP dans un nouveau projet Overleaf.
2. Sur Overleaf, sélectionner **pdfLaTeX** et ce fichier comme document principal.
3. Garder les deux logos `emsi_ecole.png` et `emsi_recherche_innovation.png`
   à côté du fichier `.tex`. Ils sont tous deux inclus dans le ZIP.
4. Chercher `METADONNEES` pour les informations de couverture et
   `DIAGRAMME` pour les figures TikZ. Le graphique de tokens est en PGFPlots.
5. Compiler de nouveau après toute modification ; plusieurs passes peuvent
   être nécessaires pour le sommaire et les renvois.

La source comprend dix figures vectorielles éditables : architecture, cas
d'utilisation, modèle de données, graphe, validation, séquence, protocole à
trois branches et trois graphiques de résultats. Les schémas sont en TikZ et
les graphiques en PGFPlots.

La couverture porte les deux logos fournis, sans les deux lignes de texte
redondantes sous le logo de l'école. Les accents verts EMSI restent discrets :
bande latérale fine, petit angle et filets allégés. Les titres, en-têtes, légendes et liens du corps
du rapport restent en noir et gris. Les diagrammes et graphiques conservent leur
palette colorée d'origine (bleu foncé, vert et rouge pour les arrêts).
Deux palettes distinctes sont définies au début du fichier : les noms
historiques `navy` et `teal` servent à la mise en page monochrome ; les
couleurs préfixées par `fig` sont réservées aux diagrammes et graphiques.
`coverGreen` et `coverDark` règlent uniquement les accents de la couverture.
Le logo institutionnel et les captures réelles gardent leurs couleurs originales.

Les six captures réelles du chapitre 4 sont intégrées dans `figures/` :

- `01_workspace.png` : vue générale fournie par l'étudiant.
- `02_decision.png` : sélection et justification de la décision.
- `03_comparison.png` : coûts et statuts des trois branches.
- `04_checks.png` : extrait de la liste des contrôles.
- `05_tokens.png` : décomposition des tokens par rôle.
- `06_custom.png` : première étape du formulaire, avec l'exemple éditable chargé.

Les captures 02 à 05 montrent l'exécution du 3 octobre 2026, référencée E5
dans l'annexe A. Ses totaux sont identiques à E3, mais ses durées diffèrent.
La trace complète est jointe dans `preuves/`. Les images sont de vraies
captures de l'application ; aucune donnée affichée n'a été remplacée.

Pour le compilateur en ligne, importer **tout le ZIP** : la source, les deux logos
et le sous-dossier `figures/` doivent conserver leur organisation. Importer
le seul fichier `.tex` ne suffit pas pour afficher les images. Les fichiers
JSON de `preuves/` documentent les captures et ne sont pas nécessaires à LaTeX.

## Informations utilisées

- Auteur : **Abdelkader Elassali**.
- Encadrant : **M. Hicham Bouchtib**.
- Organisme : **EMSI Recherche & Innovation**, d'après l'indication et le logo fournis.
- Établissement, filière et année repris du modèle à la demande de l'étudiant :
  EMSI, 4e année en Ingénierie Informatique et Réseaux, **2025/2026**.
- Sujet : *Token-Efficient Cooperative LLM-based Multi-Agent Systems*.

La période de stage a été retirée à la demande de l'étudiant. Confirmer
l'année universitaire avant dépôt : les mesures décrites datent des 1er et
3 octobre 2026. La valeur 2025/2026 reste celle communiquée par l'étudiant.
Relire les remerciements et compléter, si nécessaire, les informations
institutionnelles à partir de documents approuvés. Aucun service, effectif ou
historique d'entreprise n'a été inventé.

## Mesures et périmètre

Le chapitre 5 distingue les six répétitions historiques v12 des expériences
v13. Il indique les trois coûts de branche, la variation des sorties, le coût
physique de l'évaluation et les arrêts pour revue. Les chemins des preuves
locales sont regroupés dans l'annexe A.

Le rapport ne garantit aucun gain minimal et ne présente pas la validation
Python comme une preuve de compréhension générale. Une décision conforme est
une décision fidèle aux règles et données déclarées.

## État de la compilation

Le compilateur intégré a été réessayé après la revue finale et l'ajout du logo. Il s'est arrêté
sur une erreur d'environnement : `Unable to find standard directories for platform`.
Le dernier PDF disponible (`rapport_token_efficient-1.pdf`, 52 pages) a été
examiné sur toutes ses pages en vue d'ensemble, puis en détail sur les figures
et tableaux présentant des défauts. Les six captures y sont présentes.
Cette revue a conduit à corriger dans la source les libellés du graphique
des répétitions, l'espacement du modèle de données et les champs trop longs
du dictionnaire. Le lien Ollama manquant et un caractère isolé ont été corrigés
dans la bibliographie. Les relevés de versions sont maintenant renseignés,
avec leur provenance et leurs limites.

La compilation et la pagination après ces modifications restent à vérifier
dans un compilateur fonctionnel ; aucun nouveau PDF n'est présenté comme
compilé. La source reste modifiable dans le même éditeur.
Les contrôles statiques de structure ne remplacent pas une compilation LaTeX.

Le ZIP contient la source, les deux logos, les six captures, la trace E5,
le relevé d'environnement et les notes de contrôle,
pas un nouveau PDF rendu. Après compilation
dans un environnement fonctionnel, vérifier les pages de garde, les tableaux,
les figures, le sommaire et les éventuels débordements avant remise.

Le fichier `CONTROLE_FINAL.md` distingue les vérifications effectuées de celles
qui nécessitent encore le PDF recompilé. Le relevé de l'environnement est
conservé dans `preuves/environnement-20261003.json` ; il ne décrit pas
rétroactivement l'environnement de chaque expérience historique.

## Organisation révisée

1. Cadre du stage et du projet.
2. Cadrage et choix techniques.
3. Conception et modélisation : source protégée, exemple de projection,
   rôles, graphe et barrières de validation.
4. Réalisation et présentation de l'application : parcours complet et
   six captures réelles de l'interface.
5. Évaluation expérimentale et discussion : trois branches, attribution,
   répétitions, revue des exigences et limites.

Les annexes contiennent les preuves, la reproduction et le dictionnaire des
résultats. Les consignes de préparation et d'édition restent dans ce guide
plutôt que dans le mémoire remis au jury.

Pour modifier les métadonnées, chercher METADONNEES dans la source. Pour
remplacer une capture, conserver son nom dans figures/. Les commandes
captureweb règlent l'échelle et la légende ; elles affichent un avertissement
explicite si le fichier manque.
